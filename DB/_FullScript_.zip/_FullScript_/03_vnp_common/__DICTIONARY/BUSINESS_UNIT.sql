﻿SET DEFINE OFF;
Insert into VNP_COMMON.BUSINESS_UNIT
   (BU_ID, BU_NAME)
 Values
   ('4', 'Ha noi');
Insert into VNP_COMMON.BUSINESS_UNIT
   (BU_ID, BU_NAME)
 Values
   ('8', 'TP Ho Chi Minh');
COMMIT;
